(function(log,lib,application,request,responseHead,commands,session) {commands.writeEscapedText("");
	commands.sendRedirect("http://www.google.com");

})