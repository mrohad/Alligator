exports.run = (function(lib,application,request,responseHead,writeEscapedText,forward,sendRedirect,write,session) {writeEscapedText("ERROR%3A%0A");
writeEscapedText(""); write(; 
})