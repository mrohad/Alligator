(function(log,lib,application,request,responseHead,commands,session) {commands.writeEscapedText("");
	commands.forward("counter.jssp");

})